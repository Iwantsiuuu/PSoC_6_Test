var group__group__bsp__pins =
[
    [ "LED Pins", "group__group__bsp__pins__led.html", "group__group__bsp__pins__led" ],
    [ "Button Pins", "group__group__bsp__pins__btn.html", "group__group__bsp__pins__btn" ],
    [ "Communication Pins", "group__group__bsp__pins__comm.html", "group__group__bsp__pins__comm" ],
    [ "Capsense", "group__group__bsp__pins__capsense.html", "group__group__bsp__pins__capsense" ],
    [ "WCO", "group__group__bsp__pins__wco.html", "group__group__bsp__pins__wco" ]
];