var group__group__bsp__pins__comm =
[
    [ "CYBSP_DEBUG_UART_RX", "group__group__bsp__pins__comm.html#gae1daa9ae5985d8f4002347eee1362c76", null ],
    [ "CYBSP_DEBUG_UART_TX", "group__group__bsp__pins__comm.html#gaea8cd882c067c13b1411796d5235286d", null ],
    [ "CYBSP_I2C_SCL", "group__group__bsp__pins__comm.html#ga034bfe0f68224dd376a9a79e07ab3451", null ],
    [ "CYBSP_I2C_SDA", "group__group__bsp__pins__comm.html#gad178ee7378678fe5829a826f9a4ed0b8", null ],
    [ "CYBSP_SWDIO", "group__group__bsp__pins__comm.html#ga9fba070d4040d6aa4f3e429bdfc38946", null ],
    [ "CYBSP_SWDCK", "group__group__bsp__pins__comm.html#ga8f50aad29445466679abdcc75dcd9796", null ],
    [ "CYBSP_UART_RX", "group__group__bsp__pins__comm.html#ga8fe68f7298c5d517551380bb12d49cda", null ],
    [ "CYBSP_UART_TX", "group__group__bsp__pins__comm.html#ga93e9ccde5f5dc113c95d46e6401c6b51", null ]
];